import React from "react";
import Register from "../../components/Register";

const page = () => {
  return (
    <div>
      <Register />
    </div>
  );
};

export default page;
